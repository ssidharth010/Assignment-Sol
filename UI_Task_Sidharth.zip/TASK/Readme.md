This is done using VanillaJS and pure css.

//////////////////////////////
Features done:

UI design
Load JSON and show data
Show order modal
Add new Order
Increment and decrement quantity
Show total and sub total
Store all these in localStorage
Get from localStorage initially
Print Bill with PDF